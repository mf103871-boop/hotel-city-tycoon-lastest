# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: game.spec.ts >> the game starts even when storage is unavailable
- Location: tests/e2e/game.spec.ts:269:1

# Error details

```
Test timeout of 45000ms exceeded while setting up "page".
```

```
Tearing down "context" exceeded the test timeout of 45000ms.
```