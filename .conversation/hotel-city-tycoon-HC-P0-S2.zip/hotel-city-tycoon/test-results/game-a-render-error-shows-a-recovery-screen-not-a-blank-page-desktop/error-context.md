# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: game.spec.ts >> a render error shows a recovery screen, not a blank page
- Location: tests/e2e/game.spec.ts:254:1

# Error details

```
Test timeout of 45000ms exceeded while setting up "page".
```