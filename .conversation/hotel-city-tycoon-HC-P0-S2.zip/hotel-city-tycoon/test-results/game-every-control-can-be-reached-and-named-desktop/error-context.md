# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: game.spec.ts >> every control can be reached and named
- Location: tests/e2e/game.spec.ts:231:1

# Error details

```
Test timeout of 45000ms exceeded while setting up "page".
```

```
Tearing down "context" exceeded the test timeout of 45000ms.
```