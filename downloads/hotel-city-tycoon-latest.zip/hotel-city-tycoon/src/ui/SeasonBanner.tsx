/**
 * The seasonal banner.
 *
 * An event that changes what the hotel earns has to say so, or the player sees
 * numbers move for no reason they can name.
 */
import { useGameStore } from '../bridge/index.ts';
import { seasonBanner } from '../bridge/selectors.ts';
import { translate } from '../i18n/index.ts';
import type { Locale } from '../i18n/index.ts';

export function SeasonBanner({ locale }: { locale: Locale }) {
  const state = useGameStore((s) => s.state);
  if (!state) return null;

  const season = seasonBanner(state.epochMs);
  if (!season) return null;

  const t = (k: string, v?: Record<string, string | number>) => translate(locale, k, v);

  return (
    <div className="pointer-events-none absolute inset-x-3 top-24 z-10 rounded-xl border border-brass-500/30 bg-ink-900/85 px-4 py-2 backdrop-blur">
      <div className="flex items-baseline gap-2">
        <span className="text-sm font-semibold text-brass-400">{t(season.nameKey)}</span>
        <span className="ms-auto font-mono text-[11px] text-slate-400">
          {t('ui.eventEnds', { days: season.daysLeft })}
        </span>
      </div>
      <p className="text-[11px] leading-snug text-slate-400">{t(season.descKey)}</p>
      <p className="mt-0.5 font-mono text-[11px] text-brass-400">
        ×{season.incomeMultiplier.toFixed(2)} · ×{season.arrivalMultiplier.toFixed(2)}
      </p>
    </div>
  );
}
