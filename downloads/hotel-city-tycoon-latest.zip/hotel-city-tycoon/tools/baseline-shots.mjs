/* global URL, fetch, indexedDB */

import { spawn } from 'node:child_process';
import { mkdir, rm } from 'node:fs/promises';
import { chromium } from '@playwright/test';

const ROOT = new URL('../', import.meta.url).pathname;
const BASE_URL = 'http://127.0.0.1:5173';
const OUTPUT_DIR = new URL('../docs/baseline-screens/', import.meta.url).pathname;
const SERVER_TIMEOUT_MS = 120_000;
const VIEWPORT = { width: 1280, height: 720 };

const shots = [
  {
    name: '01-main.png',
    viewport: VIEWPORT,
    step: async () => Promise.resolve(),
  },
  {
    name: '02-build.png',
    viewport: VIEWPORT,
    step: async (page) => {
      await page.getByRole('button', { name: /\+ build/i }).click({ timeout: 60_000 });
      await page.getByRole('heading', { name: /build/i }).waitFor({ state: 'visible' });
    },
  },
  {
    name: '03-decor.png',
    viewport: VIEWPORT,
    step: async (page) => {
      await page.getByRole('button', { name: /^shop$/i }).click({ timeout: 60_000 });
      await page.getByRole('heading', { name: /^shop$/i }).waitFor({ state: 'visible' });
    },
  },
  {
    name: '04-manage.png',
    viewport: VIEWPORT,
    step: async (page) => {
      await page.getByTestId('open-manage').click({ timeout: 60_000 });
      await page.getByTestId('manage-tab-plot').waitFor({ state: 'visible' });
    },
  },
  {
    name: '05-phone.png',
    viewport: { width: 412, height: 915 },
    step: async () => Promise.resolve(),
  },
];

const failures = [];
let server;
let serverPid;
let browser;

function errorMessage(error) {
  return error instanceof Error ? error.stack ?? error.message : String(error);
}

function recordFailure(name, reason) {
  failures.push({ name, reason });
  console.error(`[baseline] ${name}: ERROR\n${reason}`);
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function waitForServer() {
  const deadline = Date.now() + SERVER_TIMEOUT_MS;
  let lastError = 'no response';
  while (Date.now() < deadline) {
    try {
      const response = await fetch(BASE_URL);
      if (response.ok) return;
      lastError = `HTTP ${response.status}`;
    } catch (error) {
      lastError = errorMessage(error);
    }
    await wait(500);
  }
  throw new Error(`server was not ready within ${SERVER_TIMEOUT_MS}ms: ${lastError}`);
}

async function bootPage(context) {
  const page = await context.newPage();
  await page.addInitScript(() => {
    void indexedDB.deleteDatabase('hotel-city-tycoon');
  });
  await page.goto(BASE_URL, { waitUntil: 'domcontentloaded', timeout: 60_000 });
  await page.getByRole('button', { name: /open hotel/i }).waitFor({
    state: 'visible',
    timeout: 20_000,
  });
  try {
    const collect = page.getByRole('button', { name: /^collect$|^اجمع/i }).first();
    await collect.waitFor({ state: 'visible', timeout: 8_000 });
    await collect.click({ timeout: 60_000 });
    await page.locator('div.z-40').first().waitFor({ state: 'hidden', timeout: 5_000 });
  } catch {
    // The daily gift is optional during baseline capture.
  }
  return page;
}

async function captureShot(shot) {
  let context;
  try {
    context = await browser.newContext({ viewport: shot.viewport });
    const page = await bootPage(context);
    await shot.step(page);
    const path = new URL(`../docs/baseline-screens/${shot.name}`, import.meta.url).pathname;
    await page.screenshot({ path, timeout: 60_000 });
    console.log(`[baseline] ${shot.name}: OK`);
  } catch (error) {
    recordFailure(shot.name, errorMessage(error));
  } finally {
    await context?.close().catch((error) => {
      console.error(`[baseline] ${shot.name}: context cleanup ERROR\n${errorMessage(error)}`);
    });
  }
}

try {
  await rm(OUTPUT_DIR, { recursive: true, force: true });
  await mkdir(OUTPUT_DIR, { recursive: true });

  server = spawn('npm', ['run', 'dev'], {
    cwd: ROOT,
    env: {
      ...process.env,
      HOST: '127.0.0.1',
      PORT: '5173',
      VITE_E2E: '1',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
    detached: true,
  });
  serverPid = server.pid;
  server.stdout.on('data', (chunk) => process.stdout.write(`[server] ${chunk}`));
  server.stderr.on('data', (chunk) => process.stderr.write(`[server] ${chunk}`));
  server.once('error', (error) => console.error(`[server] ERROR\n${errorMessage(error)}`));

  await waitForServer();
  const channel = process.env.PLAYWRIGHT_FULL_CHROMIUM === '1'
    ? 'chromium'
    : process.env.CHROMIUM_CHANNEL;
  const extraArgs = process.env.PLAYWRIGHT_EXTRA_ARGS?.trim()
    ? process.env.PLAYWRIGHT_EXTRA_ARGS.trim().split(/\s+/)
    : [];
  browser = await chromium.launch({
    ...(channel ? { channel } : {}),
    args: ['--disable-dev-shm-usage', ...extraArgs],
  });

  for (const shot of shots) {
    await captureShot(shot);
  }
} catch (error) {
  const reason = errorMessage(error);
  console.error(`[baseline] fatal ERROR\n${reason}`);
  for (const shot of shots) {
    if (!failures.some((failure) => failure.name === shot.name)) {
      recordFailure(shot.name, reason);
    }
  }
} finally {
  await browser?.close().catch((error) => {
    console.error(`[baseline] browser cleanup ERROR\n${errorMessage(error)}`);
  });
  if (failures.length > 0) {
    console.error(`[baseline] ${failures.length}/${shots.length} shots failed`);
  } else {
    console.log(`[baseline] completed ${shots.length}/${shots.length} shots`);
  }
  if (serverPid) {
    try {
      process.kill(-serverPid, 'SIGTERM');
    } catch (error) {
      if (error?.code !== 'ESRCH') {
        console.error(`[baseline] server cleanup ERROR\n${errorMessage(error)}`);
      }
    }
  }
  process.exit(failures.length > 0 ? 1 : 0);
}
